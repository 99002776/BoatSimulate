package com.boat;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BoatSimulatorApplicationTests {

	@Test
	void contextLoads() {
	}

}
