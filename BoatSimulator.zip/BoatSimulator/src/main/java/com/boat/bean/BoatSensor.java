package com.boat.bean;

public class BoatSensor {

}
